#ifndef __RESOURCES_H__
#define __RESOURCES_H__
//-----------------------------------------------------------------------------
/* TEMPORAL hasta decidir que hago con resources */

typedef int Resource;

#define WHEAT 1
#define WOOD 2
#define IRON 3
#define COAL 4

//-----------------------------------------------------------------------------
#endif // __RESOURCES_H__
