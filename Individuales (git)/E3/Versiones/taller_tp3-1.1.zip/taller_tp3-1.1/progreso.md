# Taller de Programación I - TP3 (6/6)

**El TP se encuentra en proceso de realización, se puede ver el progreso realizado en este archivo.**

El objetivo de este archivo es establecer desde el día uno un plan de ejecución a seguir bien claro que me permita llegar a un resultado final bien diseñado, legible y con poco acomplamiento sin morir en el intento.

El plan se basa en el mostrado por Martín en la clase del 19 de mayo.

*A medida que se realicen las etapas, ir tachandolas (utilizando ~~ text ~~)*.

### ~Etapa 1: diseño completo~
- Observaciones: -.

### ~Etapa 2: API servidor / API cliente (fakes)~ 
- Observaciones: la API servidor se probo en el mismo aplicativo cliente.

### ~Etapa 3: resolver la lógica~
- Observaciones: -.

### ~Etapa 4: serialización (en el mismo método)~
- Observaciones: por ahora el protocolo se encarga de serializar a los comandos. Se podría hacer que los comandos se sepan serializar pero no me gusta.

### ~Etapa 5: introducción de Sockets (cliente/servidor)~
- Observaciones: -.

### ~Etapa 6: introducción de Threads (multi-cliente)~
- Observaciones: -.